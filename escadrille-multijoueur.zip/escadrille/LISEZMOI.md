# Escadrille : multijoueur en ligne

Ce dossier contient le jeu complet et son serveur. Une fois le serveur lancé, tes amis n'ont besoin que de l'adresse du jeu : pas de compte, pas d'installation.

Le dossier contient :
- `server.js` : le serveur, qui envoie le jeu et relaie les parties ;
- `public/index.html` : le jeu ;
- `package.json` : la liste des dépendances.

## Option 1 : jouer sur le même Wi-Fi

C'est la façon la plus rapide de tester entre amis à la maison.

1. Installe **Node.js** (version LTS) depuis https://nodejs.org.
2. Décompresse ce dossier et ouvre un terminal à l'intérieur. Sous Windows : clic droit dans le dossier, puis « Ouvrir dans le terminal ».
3. Tape ces deux commandes :
   ```
   npm install
   npm start
   ```
4. Le terminal affiche les adresses du jeu :
   - **Sur cet ordinateur :** http://localhost:3000
   - **Sur le même Wi-Fi :** http://192.168.x.x:3000. C'est l'adresse à donner à tes amis.

Si Windows demande l'autorisation du pare-feu pour Node.js, accepte pour les **réseaux privés**. Le serveur tourne tant que le terminal reste ouvert ; ferme-le ou fais Ctrl+C pour l'arrêter.

## Option 2 : mettre le jeu sur Internet gratuitement (Render)

Avec cette option, tes amis peuvent jouer de n'importe où, sur téléphone ou ordinateur.

1. **Mets le projet sur GitHub :**
   - Crée un compte sur https://github.com.
   - Crée un nouveau dépôt (« New repository »).
   - Envoie les fichiers avec « Add file », puis « Upload files » : `server.js`, `package.json`, `.gitignore` et le dossier `public`. N'envoie pas le dossier `node_modules`.
2. **Crée le service sur Render :**
   - Crée un compte sur https://render.com, puis clique sur **New → Web Service** et choisis ton dépôt.
   - Remplis les réglages :
     - Runtime : **Node**
     - Build Command : `npm install`
     - Start Command : `npm start`
     - Instance Type : **Free**
3. Render te donne une adresse du type `https://escadrille-xxxx.onrender.com`. **C'est le lien à partager.**

Pour mettre à jour le jeu plus tard, il suffit de remplacer `public/index.html` sur GitHub. Render redéploie tout seul.

Deux choses à savoir sur l'offre gratuite de Render :
- **Mise en veille :** le serveur s'endort après 15 minutes sans joueur. La première visite après une pause prend alors environ une minute, le temps qu'il se réveille.
- **Redémarrages :** Render peut redémarrer le serveur de temps en temps. Le jeu se reconnecte automatiquement en quelques secondes.

## Jouer en ligne

1. Chaque joueur ouvre l'adresse du jeu, choisit son nom et sa couleur.
2. Tout le monde tape **le même nom de salon** (« arene » par défaut) et clique sur **Jouer en ligne**.
3. Pour une partie privée, choisissez un nom de salon que vous seuls connaissez.

Chaque salon accepte jusqu'à 16 pilotes, et on peut arriver ou partir en pleine partie. Les bots complètent automatiquement quand il y a peu de joueurs. Le bouton **Décoller** lance toujours une partie solo, sans réseau.

## Réglage avancé

Le serveur écoute sur le port 3000 par défaut. Pour en changer, définis la variable d'environnement `PORT`, par exemple `PORT=8080 npm start`. Render la règle automatiquement.
